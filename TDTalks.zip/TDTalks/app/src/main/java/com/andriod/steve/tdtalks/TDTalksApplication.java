package com.andriod.steve.tdtalks;

import android.app.Application;

/**
 * Created by Postma29 on 11/12/2015.
 */
public class TDTalksApplication extends Application{

    //CTOR
    public TDTalksApplication(){
        super();
    }

}
